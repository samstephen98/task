<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="/css/jquery.datetimepicker.css"/>




<!-- Latest compiled and minified JavaScript -->
<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> -->


 <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" 
dintegrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd"
 crossorigin="anonymous"></script>
 <script src="https://unpkg.com/bootstrap-table@1.15.4/dist/bootstrap-table.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js"></script>
  

</head>
<body>
<script>
function actionFormatter(value, row, index){
    return[
        '<a title=" Edit the user" class="Modeledit"><i class="glyphicon glyphicon-edit"></i></a><a title=" Delete the user" class="Modeldel"><i class="glyphicon glyphicon-trash"></i></a>' 
    ].join('');
}
window.actionModeldel={
'click .Modeldel': function(e, value, row, index){

    $("#call_id").val(row['call_id']);
    $("#assign").modal('show');
},
'click .Modeledit': function(e, value, row, index){

$("#call_id").val(row['call_id']);
$("#client_name").val(row['client_name']);
$("#from_time").val(row['from_time']);
$("#to_time").val(row['to_time']);
$("#call_notes").val(row['call_notes']);

}


}
</script>

<div class="container">

<div class="row">
<div class="col-md-12">
<div class="col-md-4"></div>


<div class="col-md-4">
<h2> Call Log</h2>
<form action="/add_log" method="post">
<input type="hidden" name="_token" value="{{csrf_token()}}" />
<input type="hidden" id="call_id" name="call_id"  />
<div class="form-group">
<label for="name">Client Name</label>

<select class="form-control" name="client_name" id="client_name">
<option value="" disabled>Select a Client name</option>
@foreach($client_details as $client)
<option value="{{$client->client_name}}">{{$client->client_name}}</option>
@endforeach
</select>
<span class="error" id="client_error"></span>
</div>

<div class="form-group">
<label for="name">From Time</label>
<input type="text" class="form-control" name="from_time" id="from_time"> 
<span class="error" id="from_error"></span>
</div>

<div class="form-group">
<label for="name">To Time</label>
<input type="text" class="form-control" name="to_time" id="to_time"> 
<span class="error" id="to_error"></span>
</div>


<div class="form-group">
<label for="name">Call Notes</label>
<input type="text" class="form-control" name="call_notes" id="call_notes"> 
<span class="error" id="notes_error"></span>
</div>

<input type="submit" class="btn btn-default" name="Submit" />

<a href="/" class="btn btn-primary">Client Details </a>


</form>
</div>

<div class="col-md-4"></div>
</div>
</div>
</div>


<div class="row">
<div class="col-md-12 table-responsive">

<table
  id="table"
  data-toggle="table"
  data-search="true"
  data-sortable="true"
  data-sort-order="asc"
  data-url="/view_log">
  <thead>
    <tr>
     
      <th data-field="client_name" data-editable="true"> Client Name</th>
      <th data-field="from_time" data-editable="true">From</th>
      <th data-field="to_time" data-editable="true">To</th>
      <th data-field="call_notes" data-editable="true">Call Notes</th>
      <th data-formatter="actionFormatter" data-events="actionModeldel">Action</th>
    </tr>
  </thead>
</table>

</div>
</div>

<div id="assign" class="modal fade" style=" background-color: rgba(0,0,0,.5);" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        
        <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-body">
              <form action="/delete_log" method="post">
              <input type="hidden" name="call_id" id="call_id"/>
              <input type="hidden" name="_token" value="{{csrf_token()}}" />
              <h4 align="center" style="color:#000000;">Are you sure to delete ?</h4>

                        <center>
                            <input type="submit" name="submit" value="Yes" class="btn btn-danger">

                            <button type="button" class="btn btn2 href2" data-dismiss="modal">No</button>

                        </center>
                        </form>
              </div>
            </div>
        </div>
        
</div>



</body>
<script>
$('#from_time').datetimepicker({
        format:'d/m/Y H:i:s'
});
$('#to_time').datetimepicker({
        format:'d/m/Y H:i:s'
}); 


$("#from_time").on('blur',function(){
    var from_time=$(this).val();
    if(from_time == "")
{
   // alert('test');
    $("#from_error").text('From Time Should not be empty');
    return true;
}else{
    $("#from_error").text(' ');
}

})

$("#to_time").on('blur',function(){
    var to_time=$(this).val();
    if(to_time == "")
{
   // alert('test');
    $("#to_error").text('To Time Should not be empty');
    return true;
}else{
    $("#to_error").text(' ');
}

})

$("#call_notes").on('blur',function(){
    var notes=$(this).val();
    if(notes == "")
{
   // alert('test');
    $("#notes_error").text('Call Notes Should not be empty');
    return true;
}else{
    $("#notes_error").text(' ');
}

})
</script>

</html>