<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Session;
use DB;


class TaskController extends Controller
{
    //

    public function index()
    {
        return view('Task.index');
    }

    public function add_client(Request $data)
    {

        $data=$data->all();
     //   dd($data);
        unset($data['_token']);
        $insert['client_name']=$data['client_name'];
        $insert['company_name']=$data['company_name'];
        $insert['phone_number']=$data['phone_no'];
        $insert['email_id']=$data['email'];
     //   dd($insert);

     if(!empty($data['client_id']))
     {
        DB::table('client_details')->where('client_id',$data['client_id'])
        ->where('status',1)
        ->update($insert);
        return redirect('/')->with('updated successfully');    
       
     }else{
        DB::table('client_details')->insert($insert);
        return redirect('/');
     }

        
    }
    public function view_client(Request $request)
    {
        if(!isset($request['order']))
        {
             if($request['order']!='desc')
             $request['order']='desc';   
        }
        if(!isset($request['search']))
        {
             if($request['search']!='%%')
             $request['search']='%%';   
        }
        if(!isset($request['sort']))
        {
             if($request['sort']!='client_id')
             $request['sort']='client_id';   
        }
        $search="%".$request['search']."%";
        $rows=DB::table('client_details')
        ->Where('status',1)
        ->Where(function($query) use($search){
            $query->orwhere('client_id','like',$search)
            ->orwhere('email_id','like',$search)
            ->orwhere('phone_number','like',$search);
        })
        ->orderBy($request['sort'],$request['order'])
        // ->skip($request['offset'])
        // ->take($request['limit'])
        ->get();



        $total=DB::table('client_details')
        ->Where('status',1)
        ->Where(function($query) use($search){
            $query->orwhere('client_id','like',$search)
            ->orwhere('email_id','like',$search)
            ->orwhere('phone_number','like',$search);
        })
        ->count();


return ['rows'=>$rows,'total'=>$total];

    }


public function update_client(Request $data)
{
    $data=$data->all();
    //   dd($data);
       unset($data['_token']);
       $insert['client_name']=$data['client_name'];
       $insert['company_name']=$data['company_name'];
       $insert['phone_number']=$data['phone_no'];
       $insert['email_id']=$data['email'];
    //   dd($insert);
       DB::table('client_details')->where('client_id',$data['client_id'])
       ->where('status',1)
       ->update($insert);
       return redirect('/')->with('updated successfully');    
}

public function delete_client(Request $data)
{
    $data=$data->all();
DB::table('client_details')->where('client_id',$data['client_id'])->update(['status'=>0]);
return redirect('/')->with('deleted successfully');    
}



    public function call_log()
    {
        $client_details=DB::table('client_details')->Where('status',1)->get();
        return view('Task.call_log')->with('client_details',$client_details);
    }

    public function add_log(Request $data)
    {
        $data=$data->all();
     // dd($data);
        unset($data['_token']);
        $insert['client_name']=$data['client_name'];
        $insert['from_time']=$data['from_time'];
        $insert['to_time']=$data['to_time'];
        $insert['call_notes']=$data['call_notes'];
     //   dd($insert);


     if(!empty($data['call_id']))
     {
        DB::table('call_logs')->Where('call_id',$data['call_id'])
        ->Where('status',1)->update($insert);
     }else{
        DB::table('call_logs')->insert($insert);
     }

        return redirect('/call_log');
    }


    public function view_log(Request $request)
    {
        if(!isset($request['order']))
        {
             if($request['order']!='desc')
             $request['order']='desc';   
        }
        if(!isset($request['search']))
        {
             if($request['search']!='%%')
             $request['search']='%%';   
        }
        if(!isset($request['sort']))
        {
             if($request['sort']!='call_id')
             $request['sort']='call_id';   
        }
        $search="%".$request['search']."%";
        $rows=DB::table('call_logs')
        ->Where('status',1)
        ->Where(function($query) use($search){
            $query->orwhere('call_id','like',$search)
            ->orwhere('client_name','like',$search)
            ->orwhere('from_time','like',$search);
        })
        ->orderBy($request['sort'],$request['order'])
        // ->skip($request['offset'])
        // ->take($request['limit'])
        ->get();



        $total=DB::table('call_logs')
        ->Where('status',1)
        ->Where(function($query) use($search){
            $query->orwhere('call_id','like',$search)
            ->orwhere('client_name','like',$search)
            ->orwhere('from_time','like',$search);
        })
        ->count();


return ['rows'=>$rows,'total'=>$total];

    }



public function delete_log(Request $data)
{
    $data=$data->all();
DB::table('call_logs')->where('call_id',$data['call_id'])->update(['status'=>0]);
return redirect('/call_log')->with('deleted successfully');    
}


public function checkName(Request $data){
    $data=$data->all();
   // dd($data);
    unset($data['_token']);
    if(isset($data['name']))
{
    $name=DB::table('client_details')->where('client_name',$data['name'])->Where('status',1)->get();
}
if(isset($data['company_name']))
{
    $name=DB::table('client_details')->where('company_name',$data['company_name'])->Where('status',1)->get();
}

    if(!empty($name)){
        return 1;
    }else{
        return 2;
    }


}













}
