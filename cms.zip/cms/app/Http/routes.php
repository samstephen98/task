<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::any('/',['uses'=>'TaskController@index']);
Route::any('/add_client',['uses'=>'TaskController@add_client']);
Route::any('/view_client',['uses'=>'TaskController@view_client']);
Route::any('/update_client',['uses'=>'TaskController@update_client']);
Route::any('/delete_client',['uses'=>'TaskController@delete_client']);


Route::any('/checkEmail',['uses'=>'TaskController@checkEmail']);
Route::any('/checkName',['uses'=>'TaskController@checkName']);


Route::any('/call_log',['uses'=>'TaskController@call_log']);
Route::any('/add_log',['uses'=>'TaskController@add_log']);
Route::any('/view_log',['uses'=>'TaskController@view_log']);
Route::any('/update_log',['uses'=>'TaskController@update_log']);
Route::any('/delete_log',['uses'=>'TaskController@delete_log']);